Locales['fi'] = {
  ['blackmarket'] = 'Likainen kauppa',
  ['blackmarkets'] = 'Likaiset kaupat',
  ['press_menu'] = 'paina [E] ostaaksesi jotain kaupasta.',
  ['blackmarket_item'] = '$%s',
  ['bought'] = 'Sinä ostit juuri %sx %s. Summaksi tuli ~r~$%s',
  ['not_enough'] = 'sinulla ei ole ~r~tarpeeksi rahaa, sinulta puuttuu ~r~$%s!',
  ['player_cannot_hold'] = 'sinulla ~r~ei ole tarpeeksi tilaa repussasi!',
  ['blackmarket_confirm'] = 'osta %sx %s summa olisi $%s?',
  ['no'] = 'ei',
  ['yes'] = 'kyllä',
}
