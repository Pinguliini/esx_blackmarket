Locales['en'] = {
  ['shop'] = 'shop',
  ['shops'] = 'shops',
  ['press_menu'] = 'press [E] to access the store.',
  ['shop_item'] = '$%s',
  ['bought'] = 'you just bought %sx %s for ~r~$%s',
  ['not_enough'] = 'you do not have ~r~enough money, you\'re missing ~r~$%s!',
  ['player_cannot_hold'] = 'you do ~r~not have enough free space in your inventory!',
  ['shop_confirm'] = 'buy %sx %s for $%s?',
  ['no'] = 'no',
  ['yes'] = 'yes',
}
