Config = {}
Config.DrawDistance = 10
Config.MarkerSize = {x = 2, y = 2, z = 2}
Config.MarkerType =  2
Config.MarkerColor = {r = 102, g = 102, b = 204, a = 255}
Config.Locale = 'fi'

Config.Zones = {

	Blackmarket = {
		Items = {
			{
				name = "luottarit",
				label = "Luotiliivi",
				price = 1000
			},			{
				name = "cuffs",
				label = "Käsiraudat",
				price = 500
			},
			{
				name = "cuff_keys",
				label = "Käsirautojen avaimet",
				price = 500
			},
			{
				name = "clip",
				label = "Lipas",
				price = 100
			},
			{
				name = "laptop_h",
				label = "Läppäri",
				price = 4000
			}
		},
		Pos = {
			vector3(-35.0899, 1950.8031, 190.5546)
	},
	Size  = 1.0,
	Type  = 59,
	Color = 5,
	ShowBlip = false,
  ShowMarker = true
}
}


